lex subc-compiler.l
yacc cCompilerWithfinc.y -d
gcc y.tab.c -ll -ly
./a.out test
